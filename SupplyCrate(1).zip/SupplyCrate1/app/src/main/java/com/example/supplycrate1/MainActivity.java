package com.example.supplycrate1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button Signup;
    TextView Login;
    ImageView top, logo;
    Animation topanim,zoom;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);

        Login=findViewById(R.id.textView5);
        Signup=findViewById(R.id.button);
        top=findViewById(R.id.imageView);
        logo=findViewById(R.id.imageView2);
        topanim = AnimationUtils.loadAnimation(this,R.anim.topdown);
        zoom = AnimationUtils.loadAnimation(this,R.anim.bganim);



        top.setAnimation(topanim);
        logo.setAnimation(topanim);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Login.class);
                view.getContext().startActivity(intent);}
        });

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), SignUp.class);
                view.getContext().startActivity(intent);}


        });



    }
}