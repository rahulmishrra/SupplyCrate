package com.example.supplycrate1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {

    Animation top,fade;
    ImageView topdesigngreen, signuptext;
    Button Signup;
    EditText name,email,pass,phone;
    DBhelper DB;
    TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_sign_up);


        Signup = findViewById(R.id.signupbtn);
        name = findViewById(R.id.txtusername);
        email = findViewById(R.id.txtemail);
        pass = findViewById(R.id.txtpassword);
        phone = findViewById(R.id.txtphone);
        DB = new DBhelper(this);
        login = findViewById(R.id.textView5);


       Signup.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String username = name.getText().toString();
               String mail = email.getText().toString();
               String password = pass.getText().toString();
               Integer phoneno = phone.getInputType();

               if(username.equals("")||mail.equals("")||password.equals("")||phoneno.equals(""))
                   Toast.makeText(SignUp.this, "Please enter all fields", Toast.LENGTH_SHORT).show();

               else{
                   Boolean checkuser = DB.checkusername(username);
                   if (checkuser==false){
                       Boolean insert = DB.insertData(username, password, mail, phoneno);
                       if (insert==true){
                           Toast.makeText(SignUp.this, "Registered Succesfully!", Toast.LENGTH_SHORT).show();
                           Intent intent = new Intent(getApplicationContext(),form1.class);
                           startActivity(intent);
                           
                       }else{
                           Toast.makeText(SignUp.this, "Registration Failed! Try again", Toast.LENGTH_SHORT).show();

                       }

                   }else{
                       Toast.makeText(SignUp.this, "User already exists, please sign in", Toast.LENGTH_SHORT).show();
                   }


               }


           }
       });

       login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(getApplicationContext(), Login.class);
               startActivity(intent);
           }
       });


        topdesigngreen=findViewById(R.id.topdesign);
        signuptext=findViewById(R.id.zoomlogo);
        top = AnimationUtils.loadAnimation(this,R.anim.topdown);
        fade = AnimationUtils.loadAnimation(this,R.anim.bganim);


        topdesigngreen.setAnimation(top);
        signuptext.setAnimation(fade);

    }
}